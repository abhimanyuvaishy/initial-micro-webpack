import React, { Component } from 'react';
import './App.css';
import items from './treeData';
import Tree from './components/tree';
//import {connect} from 'react-redux';

class App extends Component {

 collapseorExpand=(e)=>{
      e.currentTarget.parentElement
      .querySelectorAll('ul').forEach(ul => {
        if (ul.offsetHeight > 0) {
          ul.style.display = 'none';
        } else {
          ul.style.display = 'block';
        }
      });
 }
 
  render() {
    return (
      <div className="App">
      <header><p>Tree</p></header>
      <div className="tree-container">
       <Tree data={items} nodeOnClick={this.collapseorExpand}/>
       </div>  
      </div>
    );
  }
}
// const mapStateToProps = state => {
//     return{
//       data:state.data
//     }
// }

// const mapDispatchToProps =(dispatch)=> {
//    return{
//         onNodeClick :()=>dispatch({type:"TREE_DATA"})
//    } 
// }
export default App;
//export default connect(mapStateToProps,mapDispatchToProps)(App);
