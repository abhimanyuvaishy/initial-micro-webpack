const initialState={
    data:{}
}

let reducer=(state=initialState,action)=>{
    if(action.type==="TREE_DATA")
        return {...state,data:action.payload};
}

export default reducer;