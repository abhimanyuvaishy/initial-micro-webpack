import React from 'react'

const Tree=(props)=>{
    return(
    <React.Fragment>
        <ul  onClick={props.collapseorExpand}>
            <li>
            <div className="expand" key={props.data.label} style={{cursor:"pointer"}}
                    onClick={props.nodeOnClick} >{props.data.label}</div>
            {props.data.items && props.data.items.map((element)=>{
                return Tree({data:element,nodeOnClick:props.nodeOnClick})
            })}
            </li></ul>
        </React.Fragment>  
    ) 
}

export default Tree;

