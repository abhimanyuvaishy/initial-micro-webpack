import React from 'react';
import ReactDOM from 'react-dom';
import Tree from './tree';
 import  items  from  "../treeData";
it('renders without crashing', () => {
  const div = document.createElement('div');
  const func=()=>console.log("Event");
  ReactDOM.render(<Tree data={items} nodeOnClick={func} />, div);
  ReactDOM.unmountComponentAtNode(div);
});