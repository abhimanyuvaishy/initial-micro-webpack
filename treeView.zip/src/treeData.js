const items = {
    label: 'Node Label Top',
    items: [
        {
            label: 'Child Node Label A',
            items: [
                {
                    label: 'Child Node Label A.a',
                    items: [
                        {
                            label: 'Child Node Label A.a.a',
                            items: []
                        },
                        {
                            label: 'Child Node Label A.a.b',
                        },
                        {
                            label: 'Leaf Node Label A.a.c'
                        }
                    ]
                }
            ]
        },
        {
            label: 'Leaf Node Label B'
        },
        {
            label: 'Leaf Node Label C'
        }
    ]
}

export default items;